//package apps.cafebazaar.all.apps.notification;/*
// * This is the source code of Telegram for Android v. 3.x.x.
// * It is licensed under GNU GPL v. 2 or later.
// * You should have received a copy of the license in this archive (see LICENSE).
// *
// * Copyright Nikolai Kudashov, 2013-2017.
// */
//
//
//import android.support.annotation.UiThread;
//import android.util.SparseArray;
//
//import java.util.ArrayList;
//
//public class NotificationCenter {
//
//    private static int totalEvents = 1;
//
//    public static final int didRecivedHomeCatagories = totalEvents++;
//
//    private SparseArray<ArrayList<Object>> observers = new SparseArray<>();
//    private SparseArray<ArrayList<Object>> removeAfterBroadcast = new SparseArray<>();
//    private SparseArray<ArrayList<Object>> addAfterBroadcast = new SparseArray<>();
//
//    private int broadcasting = 0;
//
//    public interface NotificationCenterDelegate {
//        void didReceivedNotification(int id, Object... args);
//    }
//
//
//    private static volatile NotificationCenter Instance = new NotificationCenter();
//
//    @UiThread
//    public static NotificationCenter getInstance() {
//        NotificationCenter localInstance = Instance;
//        if (localInstance == null) {
//            synchronized (NotificationCenter.class) {
//                localInstance = Instance;
//                if (localInstance == null) {
//                    Instance = localInstance = new NotificationCenter();
//                }
//            }
//        }
//        return localInstance;
//    }
//
//
//    public NotificationCenter() {
//    }
//
//
//    public void postNotificationName(int id, Object... args) {
//
//        postNotificationNameInternal(id, args);
//    }
//
//    @UiThread
//    public void postNotificationNameInternal(int id, Object... args) {
//
//        broadcasting++;
//        ArrayList<Object> objects = observers.get(id);
//        if (objects != null && !objects.isEmpty()) {
//            for (int a = 0; a < objects.size(); a++) {
//                Object obj = objects.get(a);
//                ((NotificationCenterDelegate) obj).didReceivedNotification(id, args);
//            }
//        }
//        broadcasting--;
//        if (broadcasting == 0) {
//            if (removeAfterBroadcast.size() != 0) {
//                for (int a = 0; a < removeAfterBroadcast.size(); a++) {
//                    int key = removeAfterBroadcast.keyAt(a);
//                    ArrayList<Object> arrayList = removeAfterBroadcast.get(key);
//                    for (int b = 0; b < arrayList.size(); b++) {
//                        removeObserver(arrayList.get(b), key);
//                    }
//                }
//                removeAfterBroadcast.clear();
//            }
//            if (addAfterBroadcast.size() != 0) {
//                for (int a = 0; a < addAfterBroadcast.size(); a++) {
//                    int key = addAfterBroadcast.keyAt(a);
//                    ArrayList<Object> arrayList = addAfterBroadcast.get(key);
//                    for (int b = 0; b < arrayList.size(); b++) {
//                        addObserver(arrayList.get(b), key);
//                    }
//                }
//                addAfterBroadcast.clear();
//            }
//        }
//    }
//
//    public void addObserver(Object observer, int id) {
//
//        if (broadcasting != 0) {
//            ArrayList<Object> arrayList = addAfterBroadcast.get(id);
//            if (arrayList == null) {
//                arrayList = new ArrayList<>();
//                addAfterBroadcast.put(id, arrayList);
//            }
//            arrayList.add(observer);
//            return;
//        }
//        ArrayList<Object> objects = observers.get(id);
//        if (objects == null) {
//            observers.put(id, (objects = new ArrayList<>()));
//        }
//        if (objects.contains(observer)) {
//            return;
//        }
//        objects.add(observer);
//    }
//
//    public void removeObserver(Object observer, int id) {
//
//        if (broadcasting != 0) {
//            ArrayList<Object> arrayList = removeAfterBroadcast.get(id);
//            if (arrayList == null) {
//                arrayList = new ArrayList<>();
//                removeAfterBroadcast.put(id, arrayList);
//            }
//            arrayList.add(observer);
//            return;
//        }
//        ArrayList<Object> objects = observers.get(id);
//        if (objects != null) {
//            objects.remove(observer);
//        }
//    }
//}
