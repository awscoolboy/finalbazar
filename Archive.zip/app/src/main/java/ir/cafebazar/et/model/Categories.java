package ir.cafebazar.et.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class Categories {


    //the main app catagories

    @SerializedName("count")
    private int count;

    @SerializedName("next")
    private String next;

    @SerializedName("previous")
    private String previous;

    @SerializedName("results")
    private List<Category> categoryList;


    public abstract class CatagoriesList implements List<Category>{

    }

    public List<Category> getCategoryList() {
        return categoryList;
    }

    public class Category implements Serializable {

        @SerializedName("id")
        private int id;

        @SerializedName("name")
        private String name;

        @SerializedName("url")
        private String url;

        @SerializedName("category_type")
        private int category_type;//1 apps 2 for games


        public Category(){
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public int getCategory_type() {
            return category_type;
        }

        public void setCategory_type(int category_type) {
            this.category_type = category_type;
        }
    }

}
