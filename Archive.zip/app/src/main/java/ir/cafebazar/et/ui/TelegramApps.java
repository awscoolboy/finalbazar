package ir.cafebazar.et.ui;

import android.support.v4.app.Fragment;

public class TelegramApps extends Fragment {
}
