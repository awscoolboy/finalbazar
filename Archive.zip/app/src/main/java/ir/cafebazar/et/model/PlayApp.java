package ir.cafebazar.et.model;


import com.google.gson.annotations.SerializedName;


public class PlayApp {

    @SerializedName("id")
    private String id;

    @SerializedName("rank")
    private String rank;

    @SerializedName("packagename")
    private String packagename;

    @SerializedName("icon")
    private String icon;

    @SerializedName("developer")
    private String developer;

    @SerializedName("category")
    private String category;

    @SerializedName("installs")
    private String installs;

    @SerializedName("rankfilter")
    private String rankfilter;

    @SerializedName("rankcat")
    private String rankcat;

    @SerializedName("name")
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getPackagename() {
        return packagename;
    }

    public void setPackagename(String packagename) {
        this.packagename = packagename;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getDeveloper() {
        return developer;
    }

    public void setDeveloper(String developer) {
        this.developer = developer;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getInstalls() {
        return installs;
    }

    public void setInstalls(String installs) {
        this.installs = installs;
    }

    public String getRankfilter() {
        return rankfilter;
    }

    public void setRankfilter(String rankfilter) {
        this.rankfilter = rankfilter;
    }

    public String getRankcat() {
        return rankcat;
    }

    public void setRankcat(String rankcat) {
        this.rankcat = rankcat;
    }
}
