package ir.cafebazar.et.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class PlayCategory {



    @SerializedName("count")
    private String count;

    @SerializedName("next")
    private String next;

    @SerializedName("previous")
    private String previous;

    @SerializedName("results")
    private ArrayList<PlayCat> playCategories;



    public ArrayList<PlayCat> getPlayCategories() {
        return playCategories;
    }

    public void setPlayCategories(ArrayList<PlayCat> playCategories) {
        this.playCategories = playCategories;
    }

    public static class PlayCat{


        @SerializedName("id")
        private String id;

        @SerializedName("catcode")
        private String catcode;


        @SerializedName("name")
        private String name;



        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getCatcode() {
            return catcode;
        }

        public void setCatcode(String catcode) {
            this.catcode = catcode;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

    }


}
