package ir.cafebazar.et.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.Objects;

import apps.cafebazaar.all.apps.R;

import ir.cafebazar.et.AndroidHelper;
import ir.cafebazar.et.ApplicationLoader;
import ir.cafebazar.et.model.PlayApp;
import ir.cafebazar.et.model.PlayCategory;
import ir.cafebazar.et.model.PlayFilter;
import ir.cafebazar.et.network.BaseApiController;


import com.bumptech.glide.Glide;


public class GooglePlayTop extends Fragment implements BaseApiController.ApiCallBack{

    private RecyclerView listView;
    private ListAdapter listAdapter;
    private Spinner catSpiner;
    private Spinner filterSpinner;
    private ProgressBar progressBar;
    private LinearLayoutManager layoutManager;
    private LinearLayout error_view;
    private ArrayList<PlayCategory.PlayCat> playCats=new ArrayList<>();
    private ArrayList<PlayFilter> playFilters=new ArrayList<>();
    private ArrayList<PlayApp> playApps=new ArrayList<>();


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=LayoutInflater.from(getContext()).inflate(R.layout.google_play_top_apps_fragment,container,false);
        catSpiner=view.findViewById(R.id.catSpinner);
        filterSpinner=view.findViewById(R.id.filterSpinner);
        progressBar=view.findViewById(R.id.progressBar);
        listView=view.findViewById(R.id.listView);
        listAdapter=new ListAdapter();
        listView.setLayoutManager(layoutManager=new LinearLayoutManager(getContext()));
        listView.setAdapter(listAdapter);
        BaseApiController.getInstance(getContext()).getPlayCategories(this);

        error_view=view.findViewById(R.id.errorView);
        Button retry = view.findViewById(R.id.retryButton);
        retry.setOnClickListener(view1 -> {
            animateProgressWithError();
            new Handler().postDelayed(() -> {
                showProgress();
                BaseApiController.getInstance(getContext()).getPlayCategories(GooglePlayTop.this);

            },300);

        });
        return view;
    }




    private void animateProgressWithError(){
        int mShortAnimationDuration=getResources().getInteger(
                android.R.integer.config_shortAnimTime);
        progressBar.setVisibility(View.VISIBLE);
        error_view.setVisibility(View.INVISIBLE);

        error_view.setAlpha(0f);
        progressBar.setVisibility(View.VISIBLE);
        progressBar.animate()
                .alpha(1f)
                .setDuration(mShortAnimationDuration)
                .setListener(null);
        error_view.animate()
                .alpha(0f)
                .setDuration(mShortAnimationDuration)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        error_view.setVisibility(View.GONE);
                    }
                });
    }



    private void showProgress(){
        if(progressBar!=null && listView!=null){
            int mShortAnimationDuration=getResources().getInteger(
                    android.R.integer.config_shortAnimTime);
            progressBar.setVisibility(View.VISIBLE);
            listView.setVisibility(View.INVISIBLE);
            progressBar.setAlpha(0f);
            progressBar.setVisibility(View.VISIBLE);
            progressBar.animate()
                    .alpha(1f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(null);
            listView.animate()
                    .alpha(0f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            listView.setVisibility(View.GONE);
                        }
                    });
        }
    }


    private void hideProgress(){
        if(progressBar!=null && listView!=null){
            int mShortAnimationDuration=getResources().getInteger(
                    android.R.integer.config_shortAnimTime);
            listView.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.INVISIBLE);
            listView.setAlpha(0f);
            listView.setVisibility(View.VISIBLE);
            listView.animate()
                    .alpha(1f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(null);
            progressBar.animate()
                    .alpha(0f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            progressBar.setVisibility(View.GONE);
                        }
                    });
        }
    }



    private void displayErrorMessage(String errorMessage){

        if(progressBar!=null && error_view!=null){

            if(errorMessage!=null){
                ((TextView)error_view.findViewById(R.id.errorText)).setText(errorMessage);
            }

            int mShortAnimationDuration=getResources().getInteger(
                    android.R.integer.config_shortAnimTime);
            error_view.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.INVISIBLE);
            error_view.setAlpha(0f);
            error_view.setVisibility(View.VISIBLE);
            error_view.animate()
                    .alpha(1f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(null);
            progressBar.animate()
                    .alpha(0f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            progressBar.setVisibility(View.GONE);
                        }
                    });
        }
    }





    @Override
    public void didReceiveData(Object object, int type) {
        if(object==null) {
            displayErrorMessage(null);
            return;
        }
        if(type== BaseApiController.didReceivePlayCategory){
            PlayCategory playCategory=(PlayCategory)object;
            playCats=playCategory.getPlayCategories();
            ArrayList<String> cats=new ArrayList<>();
            for(PlayCategory.PlayCat playCat:playCats){
                cats.add(playCat.getName());
            }
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(Objects.requireNonNull(getContext()), android.R.layout.simple_spinner_item,cats);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            catSpiner.setAdapter(dataAdapter);
            catSpiner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    if(catSpiner.getCount()==0 || filterSpinner.getCount()==0){
                        return;
                    }
                    ++ApplicationLoader.counter;
                    if(ApplicationLoader.counter%3==0){
                        if(getContext() instanceof MainActivity){
                            ((MainActivity) getContext()).showAdd();
                            return;
                        }

                    }

                    showProgress();
                    BaseApiController.getInstance(getContext()).getPlayApps(playCats.get(catSpiner.getSelectedItemPosition()).getId(),
                            playFilters.get(filterSpinner.getSelectedItemPosition()).getId(),GooglePlayTop.this);
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }
            });

            BaseApiController.getInstance(getContext()).getPlayFilters(this);
        }else if(type== BaseApiController.didReceivePlayFilters){
              playFilters=(ArrayList<PlayFilter>)object;
              final ArrayList<String> filters=new ArrayList<>();
              for(PlayFilter filter:playFilters){
                 filters.add(filter.getName());
              }
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(Objects.requireNonNull(getContext()), android.R.layout.simple_spinner_item,filters);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            filterSpinner.setAdapter(dataAdapter);
            filterSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    if(catSpiner.getCount()==0 || filterSpinner.getCount()==0){
                        return;
                    }
                    ++ApplicationLoader.counter;
                    if(ApplicationLoader.counter%3==0){
                        if(getContext() instanceof MainActivity){
                            ((MainActivity) getContext()).showAdd();
                            return;
                        }

                    }



                    showProgress();
                    BaseApiController.getInstance(getContext()).getPlayApps(playCats.get(catSpiner.getSelectedItemPosition()).getId(),
                            playFilters.get(filterSpinner.getSelectedItemPosition()).getId(),GooglePlayTop.this);
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }
            });

            if(catSpiner.getCount()==0 || filterSpinner.getCount()==0){
                return;
            }
            BaseApiController.getInstance(getContext()).getPlayApps(playCats.get(catSpiner.getSelectedItemPosition()).getId(),
                    playFilters.get(filterSpinner.getSelectedItemPosition()).getId(),this);

        }else if(type== BaseApiController.didReceivedPlayApps){

            playApps=(ArrayList<PlayApp>)object;
            listAdapter.notifyDataSetChanged();
            layoutManager.scrollToPositionWithOffset(0, 0);
            hideProgress();
        }

    }


    @Override
    public void onError(String error_message) {
        displayErrorMessage(getString(R.string.unknow_error));

    }


    private class ListAdapter extends RecyclerView.Adapter<ListAdapter.TextViewHolder>{

        @NonNull
        @Override
        public TextViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view=LayoutInflater.from(getContext()).inflate(R.layout.category_item,viewGroup,false);
            return new TextViewHolder(view);
        }


        @Override
        public void onBindViewHolder(@NonNull TextViewHolder textViewHolder, final int i) {
           final PlayApp playApp=playApps.get(i);
           textViewHolder.rank.setText(playApp.getRank());
           textViewHolder.devloperName.setText("by " + AndroidHelper.foramtString(playApp.getDeveloper()));
           textViewHolder.title.setText(AndroidHelper.foramtString(playApp.getName()));
           Glide.with(ApplicationLoader.applicationContext).load("http://159.65.94.189:800/media/"+ playApp.getIcon()).into(textViewHolder.logo);

           textViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   ++ApplicationLoader.counter;
                   if(ApplicationLoader.counter%3==0){
                       if(getContext() instanceof MainActivity){
                           ((MainActivity) getContext()).showAdd();
                           return;
                       }

                   }
                   AndroidHelper.openAppRating(getContext(),playApp.getPackagename());

               }
           });

           textViewHolder.more.setOnClickListener(view -> {



               PopupMenu popupMenu=new PopupMenu(getContext(),textViewHolder.more);
               popupMenu.getMenu().add(getString(R.string.share_app));
              // popupMenu.getMenu().add(getString(R.string.downlod_on_telegram));

               popupMenu.setOnMenuItemClickListener(menuItem -> {
                   if(menuItem.getTitle().equals(getString(R.string.share_app))){

                       ++ApplicationLoader.counter;
                       if(ApplicationLoader.counter%3==0){
                           if(getContext() instanceof MainActivity){
                               ((MainActivity) getContext()).showAdd();
                               return false;
                           }

                       }

                       AndroidHelper.share("https://play.google.com/store/apps/details?id=" +playApp.getPackagename(),getContext());
                   }else if(menuItem.getTitle().equals(getString(R.string.downlod_on_telegram))){
                       AndroidHelper.share("https://telegram.me/apkdl_bot",getContext());
                   }

                   return true;
               });
               popupMenu.show();
           });
        }

        @Override
        public int getItemCount() {
            return playApps!=null?playApps.size():0;
        }

        class TextViewHolder extends RecyclerView.ViewHolder{

            TextView title;
            TextView devloperName;
            ImageView logo;
            TextView rank;
            ImageView more;

            TextViewHolder(@NonNull View itemView) {
                super(itemView);
                title=itemView.findViewById(R.id.titile);
                devloperName=itemView.findViewById(R.id.devloper);
                rank=itemView.findViewById(R.id.rank);
                logo=itemView.findViewById(R.id.logo);
                more=itemView.findViewById(R.id.more);

            }
        }

    }



}
