//package ir.cafebazar.et.ui;
//
//import android.content.Context;
//
//import com.quinny898.library.persistentsearch.SearchBox;
//
//import com.quinny898.library.persistentsearch.SearchBox;
//
//import com.quinny898.library.persistentsearch.BuildConfig;
//
//import  com.quinny898.library.persistentsearch.OptionsMenuListener;
//
//import .
//
//public class MatrialSearchView extends SearchBox{
//
//
//    com.quinny898.library.persistentsearch
//
//
//    public MatrialSearchView(Context context) {
//        super(context);
//    }
//
//
//
//}
