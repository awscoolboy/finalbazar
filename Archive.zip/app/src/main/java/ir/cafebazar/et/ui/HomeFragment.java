package ir.cafebazar.et.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import apps.cafebazaar.all.apps.R;
import ir.cafebazar.et.AndroidHelper;
import ir.cafebazar.et.ApplicationLoader;
import ir.cafebazar.et.model.CafeBazarApp;
import ir.cafebazar.et.model.Categories;
import ir.cafebazar.et.model.SectionDataModel;
import ir.cafebazar.et.model.collections.CollDataModel;
import ir.cafebazar.et.model.collections.Collections;
import ir.cafebazar.et.model.collections.Subcollection;
import ir.cafebazar.et.network.BaseApiController;



public class HomeFragment extends Fragment{

    private RecyclerView listView;
    private ArrayList<Object> allApps;
    private RecyclerViewDataAdapter adapter;
    private ProgressBar progressBar;
    private LinearLayout error_view;
    private int endSize;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=LayoutInflater.from(getContext()).inflate(R.layout.ic_home_fragment,container,false);
        listView=view.findViewById(R.id.listView);
        progressBar=view.findViewById(R.id.progressBar);
        error_view=view.findViewById(R.id.errorView);
        Button retry = view.findViewById(R.id.retryButton);
        retry.setOnClickListener(view1 -> {
            animateProgressWithError();
            new Handler().postDelayed(this::getData,300);
        });
        allApps=new ArrayList<>();
        listView.setHasFixedSize(true);
        listView.setItemAnimator(new DefaultItemAnimator());
        adapter = new RecyclerViewDataAdapter(getContext());
        listView.setAdapter(adapter);
        listView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        getData();
        return view;
    }


     private void getData(){
         BaseApiController.getInstance(getContext()).getHomeCategories(new BaseApiController.ApiCallBack() {
             @Override
             public void didReceiveData(Object object, int type) {
                 if(type== BaseApiController.didReceivedHomeCategories){
                     if(object==null){
                         displayErrorMessage(getString(R.string.unknow_error));
                         return;
                     }

                     List<Categories.Category> categories=(List<Categories.Category>)object;
                     endSize=categories.size();
                     for(Categories.Category category:categories){
                         getAppsForSubCatagories(category);
                     }
                 }
             }


             @Override
             public void onError(String error_message) {

                 if(AndroidHelper.isNetworkOnline()){
                     displayErrorMessage(getString(R.string.unknow_error));
                 }else{
                     displayErrorMessage(null);
                 }
             }
         });

     }



    private void getAppsForSubCatagories(final Categories.Category subCategories){
        BaseApiController.getInstance(getContext()).getHomeSubCatagoryApps(subCategories.getId(), new BaseApiController.ApiCallBack() {
            @Override
            public void didReceiveData(Object object, int type) {
                if(object==null){
                    displayErrorMessage(getString(R.string.unknow_error));
                    return;
                }

                if(type== BaseApiController.didReceivedHomeSubCatApps){
                    ArrayList<CafeBazarApp> bazaarApps=(ArrayList<CafeBazarApp>) object;
                    if(bazaarApps.size()!=0){
                        SectionDataModel dataModel=new SectionDataModel();
                        dataModel.setHeaderTitle(subCategories.getName());
                        dataModel.setCafeBazarApps(bazaarApps);
                        adapter.addToDataList(dataModel);
                        if(listView.getVisibility()!=View.VISIBLE){
                            hideProgress();
                            loadMore();
                        }

                    }
                }
            }

            @Override
            public void onError(String error_message) {
                if(AndroidHelper.isNetworkOnline()){
                    displayErrorMessage(getString(R.string.unknow_error));
                }else{
                    displayErrorMessage(null);
                }
            }
        });
    }




    private void loadMore(){

        BaseApiController.getInstance(getContext()).getCollection(new BaseApiController.ApiCallBack() {
            @Override
            public void didReceiveData(Object object, int type) {
                if(object==null){
                    return;
                    //displayErrorMessage("");
                }
                if(type==BaseApiController.didReceiveCollations){
                    Collections collection=(Collections)object;
                    if(collection.getResults()==null || collection.getResults().isEmpty()){
                        return;
                    }

                    int i=0;
                    for(Collections.Collection coll:collection.getResults()){
                        i+=3;
                        int finalI = i;
                        BaseApiController.getInstance(getContext()).getSubCollForCollId(coll.getId(), new BaseApiController.ApiCallBack() {
                            @Override
                            public void didReceiveData(Object object, int type) {
                                if(object==null){
                                    return;
                                }

                                if(type==BaseApiController.didReceiveSubCollations){
                                    ArrayList<Subcollection> subcollections=(ArrayList<Subcollection>)object;
                                    CollDataModel collDataModel=new CollDataModel();
                                    collDataModel.setHeaderTitle(coll.getName());
                                    collDataModel.setAppCollecation(subcollections);
                                    adapter.addToDataList(collDataModel);

                                }


                            }

                            @Override
                            public void onError(String error_message) {

                            }
                        });


                    }

                }
            }

            @Override
            public void onError(String error_message) {

            }
        });

    }


    public class AppCollListADapter extends RecyclerView.Adapter<AppCollListADapter.SingleItemRowHolder>{

        private ArrayList<Subcollection> itemModels;
        private Context mContext;

        public AppCollListADapter(ArrayList<Subcollection> itemModels, Context mContext) {
            this.itemModels = itemModels;
            this.mContext = mContext;
        }

        @Override
        public SingleItemRowHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.coll_sub_layout, null);
            return new SingleItemRowHolder(v);
        }

        @Override
        public void onBindViewHolder(final SingleItemRowHolder holder, final int position) {
            Subcollection itemModel = itemModels.get(position);
            holder.coll_titile.setText(AndroidHelper.foramtString(itemModel.getName()));
            Glide.with(ApplicationLoader.applicationContext)
                    .load(itemModel.getImg())
                    .into(holder.coll_image);

        }

        @Override
        public int getItemCount() {
            return (null != itemModels ? itemModels.size() : 0);
        }

        public class SingleItemRowHolder extends RecyclerView.ViewHolder {

            private ImageView coll_image;
            private TextView coll_titile;

            public SingleItemRowHolder(View itemView) {
                super(itemView);
                coll_image=itemView.findViewById(R.id.coll_image);
                coll_titile=itemView.findViewById(R.id.colTitile);

            }
        }
    }

    public class SectionListDataAdapter extends RecyclerView.Adapter<SectionListDataAdapter.SingleItemRowHolder>{

        private List<CafeBazarApp> itemModels;
        private Context mContext;

        public SectionListDataAdapter(List<CafeBazarApp> itemModels, Context mContext) {
            this.itemModels = itemModels;
            this.mContext = mContext;
        }

        @Override
        public SingleItemRowHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.app_item_cell, null);
            return new SingleItemRowHolder(v);
        }

        @Override
        public void onBindViewHolder(final SingleItemRowHolder holder, final int position) {
            CafeBazarApp itemModel = itemModels.get(position);
            holder.app_name.setText(AndroidHelper.foramtString(itemModel.getName()));
            holder.app_size.setText(AndroidHelper.foramtString(itemModel.getSize()));
            Glide.with(ApplicationLoader.applicationContext)
                    .load("http://159.65.94.189:800/media/"+ itemModel.getIcon())
                    .into(holder.app_icon);
            holder.itemView.setOnClickListener(view -> {

                ++ApplicationLoader.counter;
                if(ApplicationLoader.counter%3==0){
                    if(getContext() instanceof MainActivity){
                        ((MainActivity) getContext()).showAdd();
                        return;
                    }
                }

                Intent intent=new Intent(getContext(),AppViewerActivity.class);
                intent.putExtra("cafe_app",itemModels.get(position));
                intent.putExtra("from_home",true);

                ActivityOptionsCompat options = ActivityOptionsCompat.
                        makeSceneTransitionAnimation(getActivity(), holder.app_icon
                                , "profile");
                startActivity(intent, options.toBundle());
            });

        }

        @Override
        public int getItemCount() {
            return (null != itemModels ? itemModels.size() : 0);
        }

        public class SingleItemRowHolder extends RecyclerView.ViewHolder {

            private ImageView app_icon;
            private TextView app_name;
            private TextView app_size;

            public SingleItemRowHolder(View itemView) {
                super(itemView);
                app_icon=itemView.findViewById(R.id.app_logo);
                app_name=itemView.findViewById(R.id.app_title);
                app_size=itemView.findViewById(R.id.app_size);

            }
        }
    }

    public class RecyclerViewDataAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

        private class MainViewHolder extends RecyclerView.ViewHolder {
            TextView itemTitle;
            RecyclerView recyclerView;
            TextView btnMore;
            FrameLayout moreFrame;
            MainViewHolder(View itemView) {
                super(itemView);
                this.itemTitle = itemView.findViewById(R.id.headerTitile);
                this.recyclerView = itemView.findViewById(R.id.listView);
                this.btnMore = itemView.findViewById(R.id.moreTextView);
                this.moreFrame=itemView.findViewById(R.id.moreItemFrame);
            }
        }

        private class ProgressViewHolder extends RecyclerView.ViewHolder {
            ProgressBar progressBar;
            ProgressViewHolder(@NonNull View itemView) {
                super(itemView);
                progressBar=itemView.findViewById(R.id.progressBar);
            }
        }

        private class CollAppViewHolder extends RecyclerView.ViewHolder{
            TextView itemTitle;
            RecyclerView recyclerView;
            public CollAppViewHolder(@NonNull View itemView) {
                super(itemView);
                this.itemTitle = itemView.findViewById(R.id.headerTitile);
                this.recyclerView = itemView.findViewById(R.id.listView);

            }
        }

        private Context mContext;
        private RecyclerView.RecycledViewPool recycledViewPool;

        private final int main_view_type=1;
        private final int progress_view_type=2;
        private final int app_coll_type=3;


        @Override
        public int getItemViewType(int position) {
            if(allApps.get(position)==null){
                return progress_view_type;
            }else if(allApps.get(position) instanceof CollDataModel){
                return app_coll_type;
            }
            return  main_view_type;

        }

        public RecyclerViewDataAdapter(Context context){
            this.mContext = mContext;
            recycledViewPool = new RecyclerView.RecycledViewPool();
        }


        public void addToDataList(Object dataModel){
            if(allApps.isEmpty()){
                allApps.add(dataModel);
                notifyItemInserted(0);
            }else{
                allApps.remove(allApps.size()-1);
                notifyItemRemoved(allApps.size()-1);
                allApps.add(dataModel);
                notifyItemInserted(allApps.size()-1);
                if(!(getItemCount()==endSize-1)){
                    allApps.add(null);
                    notifyItemInserted(allApps.size()-1);
                }else{
                   if(allApps.get(allApps.size()-1)==null){
                       allApps.remove(allApps.size()-1);
                   }
                }
            }
        }


        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            if(viewType==main_view_type){
                View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.app_horizontal_layout, parent,false);
                return new MainViewHolder(v);
            }else if(viewType==app_coll_type){
                View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.coll_layout, parent,false);
                return new CollAppViewHolder(v);
            } else {
                View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_progress, parent,false);
                return new ProgressViewHolder(v);
            }
        }



        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position) {
            if(getItemViewType(position)==main_view_type){

                SectionDataModel sectionDataModel=(SectionDataModel)allApps.get(position);
                MainViewHolder holder=(MainViewHolder)viewHolder;
                final String sectionName = sectionDataModel.getHeaderTitle();
                final List singleSectionItems = sectionDataModel.getCafeBazarApps();
                holder.itemTitle.setText(AndroidHelper.foramtString(sectionName));
                SectionListDataAdapter adapter = new SectionListDataAdapter(singleSectionItems, mContext);
                holder.recyclerView.setHasFixedSize(true);
                holder.recyclerView.setLayoutManager(new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false));
                holder.recyclerView.setAdapter(adapter);
                holder.recyclerView.setRecycledViewPool(recycledViewPool);


                if(singleSectionItems.size()<=3){
                    holder.btnMore.setVisibility(View.INVISIBLE);
                }else{
                    holder.btnMore.setVisibility(View.VISIBLE);
                }

               holder.moreFrame.setOnClickListener(view -> {

                   Intent intent=new Intent(getContext(),MoreAppsActivity.class);
                   Bundle bundle = new Bundle();
                   bundle.putSerializable("apps",(Serializable)singleSectionItems);
                   bundle.putBoolean("from_home",true);
                   bundle.putString("header",AndroidHelper.foramtString(sectionName));
                   intent.putExtra("bundle",bundle);
                   startActivity(intent);
               });
            }else if(getItemViewType(position)==app_coll_type){

                CollDataModel collection=(CollDataModel)allApps.get(position);
                CollAppViewHolder holder=(CollAppViewHolder)viewHolder;
                final String sectionName = collection.getHeaderTitle();
                holder.itemTitle.setText(AndroidHelper.foramtString(sectionName));
                AppCollListADapter adapter = new AppCollListADapter(collection.getAppCollecation(), mContext);
                holder.recyclerView.setHasFixedSize(true);
                holder.recyclerView.setLayoutManager(new LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL, false));
                holder.recyclerView.setAdapter(adapter);
                holder.recyclerView.setRecycledViewPool(recycledViewPool);


            }

        }



        @Override
        public int getItemCount() {
            return (null != allApps ? allApps.size() : 0);
        }

    }

    private void showProgress(){
        if(progressBar!=null && listView!=null){
            int mShortAnimationDuration=getResources().getInteger(
                    android.R.integer.config_shortAnimTime);
            progressBar.setVisibility(View.VISIBLE);
            listView.setVisibility(View.INVISIBLE);
            progressBar.setAlpha(0f);
            progressBar.setVisibility(View.VISIBLE);
            progressBar.animate()
                    .alpha(1f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(null);
            listView.animate()
                    .alpha(0f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            listView.setVisibility(View.GONE);
                        }
                    });
        }
    }

    private void hideProgress(){
        if(progressBar!=null && listView!=null){
            error_view.setVisibility(View.INVISIBLE);
            int mShortAnimationDuration=getResources().getInteger(
                    android.R.integer.config_shortAnimTime);
            listView.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.INVISIBLE);
            listView.setAlpha(0f);
            listView.setVisibility(View.VISIBLE);
            listView.animate()
                    .alpha(1f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(null);
            progressBar.animate()
                    .alpha(0f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            progressBar.setVisibility(View.GONE);
                        }
                    });
        }
    }

    private void animateProgressWithError(){

        int mShortAnimationDuration=getResources().getInteger(
                android.R.integer.config_shortAnimTime);
        progressBar.setVisibility(View.VISIBLE);
        error_view.setVisibility(View.INVISIBLE);

        error_view.setAlpha(0f);
        progressBar.setVisibility(View.VISIBLE);
        progressBar.animate()
                .alpha(1f)
                .setDuration(mShortAnimationDuration)
                .setListener(null);
        error_view.animate()
                .alpha(0f)
                .setDuration(mShortAnimationDuration)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        error_view.setVisibility(View.GONE);
                    }
                });
    }

    private void displayErrorMessage(String errorMessage){

        if(progressBar!=null && error_view!=null){

            if(errorMessage!=null){
                ((TextView)error_view.findViewById(R.id.errorText)).setText(errorMessage);
            }


            int mShortAnimationDuration=getResources().getInteger(
                    android.R.integer.config_shortAnimTime);
            error_view.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.INVISIBLE);
            error_view.setAlpha(0f);
            error_view.setVisibility(View.VISIBLE);
            error_view.animate()
                    .alpha(1f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(null);
            progressBar.animate()
                    .alpha(0f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            progressBar.setVisibility(View.GONE);
                        }
                    });
        }
    }





}
