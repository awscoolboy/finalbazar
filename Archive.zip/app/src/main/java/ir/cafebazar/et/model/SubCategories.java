package ir.cafebazar.et.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class SubCategories {

    public abstract class  SubCatList implements List<SubCategories>{

    }


    @SerializedName("id")
    private int id;

    @SerializedName("name")
    private String name;

    @SerializedName("url")
    private String url;

    @SerializedName("category_type")
    private int category_type;


    public SubCategories(){
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getCategory_type() {
        return category_type;
    }

    public void setCategory_type(int category_type) {
        this.category_type = category_type;
    }



}
