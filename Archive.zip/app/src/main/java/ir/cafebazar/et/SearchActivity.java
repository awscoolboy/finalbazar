package ir.cafebazar.et;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;


import apps.cafebazaar.all.apps.R;
import ir.cafebazar.et.model.CafeBazarApp;
import ir.cafebazar.et.network.BaseApiController;
import ir.cafebazar.et.ui.AppViewerActivity;


public class SearchActivity extends Activity implements SearchView.OnQueryTextListener {


    private RecyclerView mRecyclerView;
    private SearchResultAdapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    private android.support.v7.widget.SearchView searchView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
        setContentView(R.layout.search_layout);
        status=findViewById(R.id.status);
        mRecyclerView = findViewById(R.id.my_recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager=new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new SearchResultAdapter();
        mRecyclerView.setAdapter(mAdapter);
        swipeRefreshLayout=findViewById(R.id.swipeRefresh);

        searchView=findViewById(R.id.search_view);
        searchView.setQueryHint("search for apps");
        searchView.onActionViewExpanded();

        searchView.setOnQueryTextListener(new android.support.v7.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                swipeRefreshLayout.setRefreshing(true);
                doSearch(s);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });

    }


    private void doSearch(String query) {
        BaseApiController.getInstance(this).searchApps(query, new BaseApiController.ApiCallBack() {
            @Override
            public void didReceiveData(Object object, int type) {

                if(type== BaseApiController.didReceivedSearchResult){

                    ArrayList<CafeBazarApp>  bazaarApps=(ArrayList<CafeBazarApp>)object;
                    if(bazaarApps.size()!=0){
                        status.setVisibility(View.GONE);
                        mAdapter.addREsults(bazaarApps);
                        mAdapter.notifyDataSetChanged();

                    }else{
                        status.setVisibility(View.VISIBLE);
                        status.setText("No item found!");

                        //emepty search result
                    }
                    swipeRefreshLayout.setRefreshing(false);

                }
            }

            @Override
            public void onError(String error_message) {

            }
        });

    }



    @Override
    public boolean onQueryTextChange(String newText) {
        return false;
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }


    public  class SearchResultAdapter extends RecyclerView.Adapter<SearchResultAdapter.ViewHolder> {

        private List<CafeBazarApp> mDataset = new ArrayList<>();


        public class ViewHolder extends RecyclerView.ViewHolder {

            private ImageView app_icon;
            private TextView app_name;


            public ViewHolder(View itemView) {
                super(itemView);
                app_icon=itemView.findViewById(R.id.app_logo);
                app_name=itemView.findViewById(R.id.app_title);
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        Intent intent=new Intent(SearchActivity.this, AppViewerActivity.class);
                        intent.putExtra("cafe_app",mDataset.get(getAdapterPosition()));
                        ActivityOptionsCompat options = ActivityOptionsCompat.
                                makeSceneTransitionAnimation(SearchActivity.this, (View)app_icon, "profile");

                        startActivity(intent, options.toBundle());


                    }
                });
            }
        }

        // Provide a suitable constructor (depends on the kind of dataset)
        public SearchResultAdapter() {
        }

        // Create new views (invoked by the layout manager)
        @Override
        public SearchResultAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                                 int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.search_item, null);
            return new ViewHolder(v);
        }

        // Replace the contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            final CafeBazarApp recipe = mDataset.get(position);

            holder.app_name.setText(foramtString(recipe.getName()));
            Glide.with(SearchActivity.this).load(recipe.getIcon()).apply(RequestOptions.circleCropTransform()).into(holder.app_icon);


        }

        @Override
        public int getItemCount() {
            return mDataset.size();
        }

        public void addResult(CafeBazarApp recipe) {
            mDataset.add(recipe);
        }

        public void addREsults(ArrayList<CafeBazarApp> apps){
            clearResults();
            mDataset.addAll(apps);
        }

        public void clearResults() {
            mDataset.clear();
        }
    }



    private String foramtString(String data){

        if(data==null)return "";

        String str = "";
        try {
            str = new String(data.getBytes("ISO-8859-1"), "UTF-8");
        } catch (UnsupportedEncodingException e) {

            e.printStackTrace();
        }
        String decodedStr = Html.fromHtml(str).toString();
        return decodedStr;
    }


}