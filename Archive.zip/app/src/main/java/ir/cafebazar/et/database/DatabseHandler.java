package ir.cafebazar.et.database;

import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;

import ir.cafebazar.et.ApplicationLoader;
import ir.cafebazar.et.database.AppDao;


public abstract class DatabseHandler extends RoomDatabase {

    private AppDao dao =new AppDao();

    private DatabseHandler instance;

    public DatabseHandler getInstance(){
        if(instance==null){
            synchronized (DatabseHandler.class){
                instance=new Room().databaseBuilder(ApplicationLoader.applicationContext,DatabseHandler.class,"caffebazzr.db")
                        .fallbackToDestructiveMigration()
                        .allowMainThreadQueries()
                        .build();
            }
        }
        return instance;
    }
}
