package ir.cafebazar.et;

import android.app.Application;
import android.os.Handler;

import com.google.android.gms.ads.MobileAds;


public class ApplicationLoader extends Application {

    public static ApplicationLoader applicationContext;
    public static Handler appHandler;

//    public static final String  APP_ID="ca-app-pub-9273346894392377~7914830765";
//    public static final String INTERSTITIAL_ID="ca-app-pub-9273346894392377/8433705519";
    public static final String Banner="";
   public static final String  APP_ID="";
  public static final String INTERSTITIAL_ID="";

    public static   int counter=0;


    @Override
    public void onCreate() {
        super.onCreate();
        applicationContext=this;
        AndroidHelper.setDisplaySize(applicationContext);
        appHandler=new Handler();
        MobileAds.initialize(this, APP_ID);

    }
}
