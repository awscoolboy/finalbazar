package ir.cafebazar.et.model;

import java.util.ArrayList;
import java.util.List;

public class SectionDataModel {

    private String headerTitle;
    private List<CafeBazarApp> cafeBazarApps;

    public String getHeaderTitle() {
        return headerTitle;
    }

    public SectionDataModel() {
    }



    public SectionDataModel(String title, List<CafeBazarApp> cafeBazarApps) {
        this.headerTitle = title;
        this.cafeBazarApps = cafeBazarApps;
    }


    public void setHeaderTitle(String headerTitle) {
        this.headerTitle = headerTitle;
    }

    public List<CafeBazarApp> getCafeBazarApps() {
        return cafeBazarApps;
    }

    public void setCafeBazarApps(List<CafeBazarApp> cafeBazarApps) {
        this.cafeBazarApps = cafeBazarApps;
    }
}
