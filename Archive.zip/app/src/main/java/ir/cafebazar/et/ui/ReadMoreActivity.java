package ir.cafebazar.et.ui;

import android.support.v7.app.AppCompatActivity;

public class ReadMoreActivity extends AppCompatActivity {
}
