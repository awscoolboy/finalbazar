package ir.cafebazar.et.model.collections;

import java.util.ArrayList;
import java.util.List;

import ir.cafebazar.et.model.collections.Collections;

public class CollDataModel {

    private String headerTitle;
    private ArrayList<Subcollection> appCollecation;

    public String getHeaderTitle() {
        return headerTitle;
    }

    public CollDataModel() {
    }

    public void setHeaderTitle(String headerTitle) {
        this.headerTitle = headerTitle;
    }

    public ArrayList<Subcollection> getAppCollecation() {
        return appCollecation;
    }

    public void setAppCollecation(ArrayList<Subcollection> appCollecation) {
        this.appCollecation = appCollecation;
    }
}
