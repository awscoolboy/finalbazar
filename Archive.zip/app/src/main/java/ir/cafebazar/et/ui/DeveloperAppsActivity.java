package ir.cafebazar.et.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;

import apps.cafebazaar.all.apps.R;

import ir.cafebazar.et.AndroidHelper;
import ir.cafebazar.et.SearchActivity;
import ir.cafebazar.et.model.CafeBazarApp;
import ir.cafebazar.et.model.Developer;
import ir.cafebazar.et.network.BaseApiController;


public class DeveloperAppsActivity extends AppCompatActivity{

    private RecyclerView listView;
    private ProgressBar progressBar;
    private GridAppAdapter adapter;
    private GridLayoutManager gridLayoutManager;
    private ArrayList<CafeBazarApp> apps;
    private Developer developer;

    private AdView mAdView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.more_app_layou);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        developer=(Developer)getIntent().getSerializableExtra("developer");

        if(developer==null){
            finish();
            return;
        }

        getSupportActionBar().setTitle(AndroidHelper.foramtString(developer.getName()));


        listView=findViewById(R.id.listView);
        listView.setHasFixedSize(true);
        progressBar=findViewById(R.id.progressBar);
        adapter = new GridAppAdapter( this);
        listView.setLayoutManager(gridLayoutManager=new GridLayoutManager(this, 3));
        listView.addItemDecoration(new GridSpacingItemDecoration(3,50,false));
        listView.setAdapter(adapter);

        BaseApiController.getInstance(this).getAppsByDevloper(developer.getId(), new BaseApiController.ApiCallBack() {
            @Override
            public void didReceiveData(Object object, int type) {
                if(object==null){
                    return;
                }
                if(type== BaseApiController.didReceiveDeveloperApps){
                    apps=(ArrayList<CafeBazarApp>)object;
                    adapter.notifyDataSetChanged();
                    hideProgress();

                }
            }
            @Override
            public void onError(String error_message) {

            }
        });


        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
    }


    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_search) {
            Intent intent=new Intent(this, SearchActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public class GridAppAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

        private class MainViewHolder extends RecyclerView.ViewHolder {
            private ImageView app_icon;
            private TextView app_name;
            private TextView app_size;

            public MainViewHolder(View itemView) {
                super(itemView);
                app_icon=itemView.findViewById(R.id.app_logo);
                app_name=itemView.findViewById(R.id.app_title);
                app_size=itemView.findViewById(R.id.app_size);

            }
        }

        private class ProgressViewHolder extends RecyclerView.ViewHolder {
            ProgressBar progressBar;
            ProgressViewHolder(@NonNull View itemView) {
                super(itemView);
                progressBar=itemView.findViewById(R.id.progressBar);
            }
        }


        private Context mContext;

        private final int main_view_type=1;
        private final int progress_view_type=2;


        @Override
        public int getItemViewType(int position) {
            if(apps.get(position)==null){
                return progress_view_type;
            }
            return  main_view_type;

        }

        public GridAppAdapter(Context context){
            this.mContext = context;
        }



        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            if(viewType==main_view_type){
                View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.app_item_cell, parent,false);
                return new MainViewHolder(v);
            }else {
                View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_progress, parent,false);
                return new ProgressViewHolder(v);
            }
        }



        @Override
        public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder viewHolder, int position) {
            if(getItemViewType(position)==main_view_type) {

                final MainViewHolder holder = (MainViewHolder) viewHolder;
                CafeBazarApp itemModel = apps.get(position);
                holder.app_name.setText(AndroidHelper.foramtString(itemModel.getName()));
                holder.app_size.setText(AndroidHelper.foramtString(itemModel.getSize()));
                Glide.with(DeveloperAppsActivity.this).load("http://159.65.94.189:800/media/"+ itemModel.getIcon()).into(holder.app_icon);

                holder.itemView.setOnClickListener(view -> {
                    Intent intent=new Intent(DeveloperAppsActivity.this,AppViewerActivity.class);
                    intent.putExtra("cafe_app",apps.get(viewHolder.getAdapterPosition()));
                    intent.putExtra("from_home",false);
                    ActivityOptionsCompat options = ActivityOptionsCompat.
                            makeSceneTransitionAnimation(DeveloperAppsActivity.this, (View)holder.app_icon, "profile");

                    startActivity(intent, options.toBundle());
                });
            }

        }



        @Override
        public int getItemCount() {
            return (null != apps ? apps.size() : 0);
        }

    }

    private void showProgress(){
        if(progressBar!=null && listView!=null){
            int mShortAnimationDuration=getResources().getInteger(
                    android.R.integer.config_shortAnimTime);
            progressBar.setVisibility(View.VISIBLE);
            listView.setVisibility(View.INVISIBLE);
            progressBar.setAlpha(0f);
            progressBar.setVisibility(View.VISIBLE);
            progressBar.animate()
                    .alpha(1f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(null);
            listView.animate()
                    .alpha(0f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            listView.setVisibility(View.GONE);
                        }
                    });
        }
    }

    private void hideProgress(){
        if(progressBar!=null && listView!=null){
            int mShortAnimationDuration=getResources().getInteger(
                    android.R.integer.config_shortAnimTime);
            listView.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.INVISIBLE);
            listView.setAlpha(0f);
            listView.setVisibility(View.VISIBLE);
            listView.animate()
                    .alpha(1f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(null);
            progressBar.animate()
                    .alpha(0f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            progressBar.setVisibility(View.GONE);
                        }
                    });
        }
    }








}
