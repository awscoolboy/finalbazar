package ir.cafebazar.et.network;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.Response.ErrorListener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;


import ir.cafebazar.et.ApplicationLoader;
import ir.cafebazar.et.model.BazaarApps;
import ir.cafebazar.et.model.CafeBazarApp;
import ir.cafebazar.et.model.Categories;
import ir.cafebazar.et.model.Developer;
import ir.cafebazar.et.model.PlayApp;
import ir.cafebazar.et.model.PlayCategory;
import ir.cafebazar.et.model.PlayFilter;
import ir.cafebazar.et.model.SubCategories;
import ir.cafebazar.et.model.collections.Collections;
import ir.cafebazar.et.model.collections.Subcollection;


public class BaseApiController{
    private static int totalEvents = 1;
    private static String base_url="http://159.65.94.189:800/";

    public static final int didReceivedHomeCategories = totalEvents++;
    public static final int didReceivedSubCategories =totalEvents++;
    public static final int didReceivedAppsForSubCategories =totalEvents++;
    public static final int didReceivedGameCategory =totalEvents++;
    public static final int didReceivedAppCategory =totalEvents++;
    public static final int didReceivedHomeSubCatApps =totalEvents++;
    public static final int didReceivedSearchResult =totalEvents++;
    public static final int didReceivePlayCategory =totalEvents++;
    public static final int didReceivePlayFilters=totalEvents++;
    public static final int didReceivedPlayApps=totalEvents++;
    public static final int didReceivedMoreApps=totalEvents++;
    public static final int didReceiveAppByPackageName =totalEvents++;
    public static final int didReceivedDeveloper=totalEvents++;
    public static final int didReceiveDeveloperApps =totalEvents++;
    public static final int didReceiveCollations=totalEvents++;
    public static final int didReceiveSubCollations=totalEvents++;


    public interface ApiCallBack{
        void didReceiveData(Object object,int type);
        void onError(String error_message);
    }

    private static BaseApiController instance;
    private RequestQueue requestQueue;
    private static Context ctx;
    private Gson gson;

    private BaseApiController(Context context) {
        ctx = context;
        requestQueue = getRequestQueue();
        gson = new GsonBuilder().create();
    }


    private void updateData(int type,Object data){
        if(data==null)return;
        SharedPreferences appPref= ApplicationLoader.applicationContext.getSharedPreferences("main_config",Context.MODE_PRIVATE);
        if(type== didReceivedGameCategory || type== didReceivedAppCategory){
            appPref.edit().putString("cat",data.toString()).apply();
        }else if(type== didReceivePlayCategory){
            appPref.edit().putString("play_cat",data.toString()).apply();
        }else if(type==didReceivePlayFilters){
            appPref.edit().putString("play_filter",data.toString()).apply();
        }
    }



    public static synchronized BaseApiController getInstance(Context context) {
        if (instance == null) {
            instance = new BaseApiController(context);
        }

        return instance;
    }

    public RequestQueue getRequestQueue() {
        if (requestQueue == null) {
            requestQueue = Volley.newRequestQueue(ctx.getApplicationContext());
        }
        return requestQueue;
    }

    public <T> void addToRequestQueue(Request<T> req) {
        getRequestQueue().add(req);
    }



    public void getAppCategory(final ApiCallBack callBack){
        final SharedPreferences appPref= ApplicationLoader.applicationContext.getSharedPreferences("main_config",Context.MODE_PRIVATE);
        final String data=appPref.getString("cat","");
        if(!data.isEmpty()){
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Categories categories=gson.fromJson(data,Categories.class);
                    final ArrayList<Categories.Category> appsList=new ArrayList<>();
                    for(Categories.Category category:categories.getCategoryList()){
                        if(category.getCategory_type()==1){
                            appsList.add(category);
                        }
                    }

                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.post(new Runnable() {
                        public void run() {
                            if(callBack!=null){
                                callBack.didReceiveData(appsList, didReceivedAppCategory);
                            }
                        }
                    });
                }
            }).start();
            return;
        }
        String  url="http://159.65.94.189:800/categories/?limit=100&offset=0";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Categories categories=gson.fromJson(response,Categories.class);
                        ArrayList<Categories.Category> appsList=new ArrayList<>();
                        for(Categories.Category category:categories.getCategoryList()){
                            if(category.getCategory_type()==1){
                                appsList.add(category);
                            }
                        }
                        if(callBack!=null){
                            callBack.didReceiveData(appsList, didReceivedAppCategory);
                            updateData(didReceivedAppCategory,response);
                        }
                    }
                },
                new ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if(callBack!=null){
                            if(error!=null && error.getMessage()!=null){
                                callBack.onError(error.getMessage());
                            }
                        }
                    }
                });
        addToRequestQueue(stringRequest);
    }



    public void getGameCategory(final ApiCallBack callBack){
        SharedPreferences appPref= ApplicationLoader.applicationContext.getSharedPreferences("main_config",Context.MODE_PRIVATE);
        final String data=appPref.getString("cat","");
        if(data.isEmpty()){

             new Thread(new Runnable() {
                 @Override
                 public void run() {
                     Categories categories=gson.fromJson(data,Categories.class);
                     final ArrayList<Categories.Category> gameList=new ArrayList<>();
                     for(Categories.Category category:categories.getCategoryList()){
                         if(category.getCategory_type()==2){
                             gameList.add(category);
                         }
                     }

                     Handler handler = new Handler(Looper.getMainLooper());
                     handler.post(new Runnable() {
                         public void run() {
                             if(callBack!=null){
                                 callBack.didReceiveData(gameList, didReceivedGameCategory);
                             }
                         }
                     });

                 }
             }).start();

             return;
         }
        String  url="http://159.65.94.189:800/categories/?limit=100&offset=0";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Categories categories=gson.fromJson(response,Categories.class);
                        ArrayList<Categories.Category> gameList=new ArrayList<>();
                        for(Categories.Category category:categories.getCategoryList()){
                            if(category.getCategory_type()==2){
                                gameList.add(category);
                            }
                        }

                        if(callBack!=null){
                            callBack.didReceiveData(gameList, didReceivedGameCategory);
                            updateData(didReceivedGameCategory,response);
                        }
                    }
                },
                new ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if(callBack!=null && error!=null){
                                callBack.onError(error.getMessage());
                        }
                    }
                });
        addToRequestQueue(stringRequest);
    }



    //get sub catagories for a commiunicationp = 5 id of com
    public void getSubCatagoriesForMainCategori(int subcat,final ApiCallBack callBack){
        String url="http://159.65.94.189:800/subcategories/" + subcat;
        Log.i("subcaturl",url);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.i("datais this",response);
                        ArrayList<SubCategories> subsCatList = (new Gson()).fromJson(response, new TypeToken<ArrayList<SubCategories>>() {}.getType());
                        if(callBack!=null){
                            callBack.didReceiveData(subsCatList, didReceivedSubCategories);
                        }
                    }
                },
                new ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if(callBack!=null && error!=null){
                            callBack.onError(error.getMessage());
                        }
                    }
                });
        addToRequestQueue(stringRequest);

    }


    public void getAppsForSubCategories(int sub_cat_id,final ApiCallBack callBack){
       String url="http://159.65.94.189:800/subcategory/" + sub_cat_id;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                         BazaarApps bazarApps=gson.fromJson(response, BazaarApps.class);
                        if(callBack!=null){
                            callBack.didReceiveData(bazarApps, didReceivedAppsForSubCategories);
                        }
                    }
                },
                new ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if(callBack!=null && error!=null){
                            callBack.onError(error.getMessage());
                        }
                    }
                });
        addToRequestQueue(stringRequest);
    }


    public void searchApps(String query,final ApiCallBack callBack){
        String url="http://159.65.94.189:800/search/" + query;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {


                    ArrayList<CafeBazarApp> subsCatList = (new Gson()).fromJson(response, new TypeToken<ArrayList<CafeBazarApp>>() {}.getType());
                    if(callBack!=null){
                        callBack.didReceiveData(subsCatList, didReceivedSearchResult);
                    }
                },
                error -> {
                    if(callBack!=null && error!=null){
                        callBack.onError(error.getMessage());
                    }
                });
        addToRequestQueue(stringRequest);
    }





    public void getHomeCategories(final  ApiCallBack callBack){
        String url="http://159.65.94.189:800/home/categories/";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    Categories categories=gson.fromJson(response,Categories.class);
                    if(callBack!=null){
                        callBack.didReceiveData(categories.getCategoryList(), didReceivedHomeCategories);
                        //updateData(didReceivedHomeCategories,response);
                    }
                },
                error -> {
                    if(callBack!=null && error!=null){
                        callBack.onError(error.getMessage());
                    }
                });
        addToRequestQueue(stringRequest);
    }


    public void getHomeSubCatagoryApps(int id,final ApiCallBack callBack){
        String url=base_url + "home/category/" + id;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    ArrayList<CafeBazarApp> subsCatList = (new Gson()).fromJson(response, new TypeToken<ArrayList<CafeBazarApp>>() {}.getType());
                    if(callBack!=null){
                        callBack.didReceiveData(subsCatList, didReceivedHomeSubCatApps);
                    }
                },
                error -> {
                    if(callBack!=null && error!=null){
                        callBack.onError(error.getMessage());
                    }
                });
        addToRequestQueue(stringRequest);

    }



    public void getPlayCategories(final ApiCallBack callBack){
        SharedPreferences preferences=ApplicationLoader.applicationContext.getSharedPreferences("main_config",Context.MODE_PRIVATE);
        String playCat=preferences.getString("play_cat","");
        if(!playCat.isEmpty()){
            PlayCategory playCategory = (new Gson()).fromJson(playCat, PlayCategory.class);
            if(callBack!=null){
                callBack.didReceiveData(playCategory, didReceivePlayCategory);
            }
            return;
        }
        String url=base_url + "rank/categories/";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                     PlayCategory playCategory = (new Gson()).fromJson(response, PlayCategory.class);
                    if(callBack!=null){
                        callBack.didReceiveData(playCategory, didReceivePlayCategory);
                    }
                    updateData(didReceivePlayCategory,response);
                },
                error -> {
                    if(callBack!=null && error!=null){
                        callBack.onError(error.getMessage());
                    }
                });
        addToRequestQueue(stringRequest);
    }


    public void getPlayFilters(final ApiCallBack callBack){
        SharedPreferences preferences=ApplicationLoader.applicationContext.getSharedPreferences("main_config",Context.MODE_PRIVATE);
        String play_filter=preferences.getString("play_filter","");
        if(!play_filter.isEmpty()){
            ArrayList<PlayFilter> filters = (new Gson()).fromJson(play_filter, new TypeToken<ArrayList<PlayFilter>>() {}.getType());
            if(callBack!=null){
                callBack.didReceiveData(filters, didReceivePlayFilters);
            }
            return;
        }
        String url="http://159.65.94.189:800/rank/filters/";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    ArrayList<PlayFilter> filters = (new Gson()).fromJson(response, new TypeToken<ArrayList<PlayFilter>>() {}.getType());
                    if(callBack!=null){
                        callBack.didReceiveData(filters, didReceivePlayFilters);
                        updateData(didReceivePlayFilters,response);
                    }
                },
                error -> {
                    if(callBack!=null && error!=null){
                        callBack.onError(error.getMessage());
                    }
                });
        addToRequestQueue(stringRequest);
    }



    public void getPlayApps(String categoryID,String filterID,final  ApiCallBack callBack){
       String url="http://159.65.94.189:800/rank/apps/" + filterID + "/" + categoryID;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    ArrayList<PlayApp> playApps = (new Gson()).fromJson(response, new TypeToken<ArrayList<PlayApp>>() {}.getType());
                    if(callBack!=null){
                        callBack.didReceiveData(playApps, didReceivedPlayApps);
                    }
                },
                error -> {
                    if(callBack!=null && error!=null){
                        callBack.onError(error.getMessage());
                    }
                });
        addToRequestQueue(stringRequest);
    }


    public void getMoreAppsForCategory(String link,final  ApiCallBack callBack){

        StringRequest stringRequest = new StringRequest(Request.Method.GET, link
                ,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        BazaarApps subsCatList = (new Gson()).fromJson(response, BazaarApps.class);
                        if(callBack!=null){
                            callBack.didReceiveData(subsCatList, didReceivedMoreApps);
                        }

                    }
                },
                new ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if(callBack!=null && error!=null){
                            callBack.onError(error.getMessage());
                        }
                    }
                });
        addToRequestQueue(stringRequest);
    }


    public void getAppbyPackageName(String packageName,final  ApiCallBack callBack){
        String url="http://159.65.94.189:800/app/" + packageName;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url
                ,
                response -> {

                 CafeBazarApp cafeBazarApp = (new Gson()).fromJson(response, CafeBazarApp.class);
                    if(callBack!=null){
                        callBack.didReceiveData(cafeBazarApp, didReceiveAppByPackageName);
                    }

                },
                error -> {
                    if(callBack!=null && error!=null){
                        callBack.onError(error.getMessage());
                    }
                });
        addToRequestQueue(stringRequest);

    }


    public void getRecomendedApps(){
        String url="https://cafebazar-4688d.firebaseio.com/recomended.json";
    }


    public void getDevloperById(String id,final  ApiCallBack callBack){
        String url="http://159.65.94.189:800/developer/" + id;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url
                ,
                response -> {

                    Developer developer = (new Gson()).fromJson(response, Developer.class);
                    if(callBack!=null){
                        callBack.didReceiveData(developer, didReceivedDeveloper);
                    }

                },
                error -> {
                    if(callBack!=null && error!=null){
                        callBack.onError(error.getMessage());
                    }
                });
        addToRequestQueue(stringRequest);

    }


    public void getAppsByDevloper(String id,final  ApiCallBack callBack){
        String url="http://159.65.94.189:800/developer/"+ id +"/apps";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    ArrayList<CafeBazarApp> cafeBazarApps = (new Gson()).fromJson(response, new TypeToken<ArrayList<CafeBazarApp>>() {}.getType());
                    if(callBack!=null){
                        callBack.didReceiveData(cafeBazarApps, didReceiveDeveloperApps);
                    }
                },
                error -> {
                    if(callBack!=null && error!=null){
                        callBack.onError(error.getMessage());
                    }
                });
        addToRequestQueue(stringRequest);
    }




    public void getSubCollection(final ApiCallBack callBack){
        String url=base_url + "home/subcollections/";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    ArrayList<CafeBazarApp> subsCatList = (new Gson()).fromJson(response, new TypeToken<ArrayList<CafeBazarApp>>() {}.getType());
                    if(callBack!=null){
                        callBack.didReceiveData(subsCatList, didReceiveSubCollations);
                    }
                },
                error -> {
                    if(callBack!=null && error!=null){
                        callBack.onError(error.getMessage());
                    }
                });
        addToRequestQueue(stringRequest);


    }

    public void getCollection(final ApiCallBack callBack){
        String url=base_url + "home/collections/";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {

            Collections collection = (new Gson()).fromJson(response, Collections.class);
                    if(callBack!=null){
                        callBack.didReceiveData(collection, didReceiveCollations);
                    }
                },
                error -> {
                    if(callBack!=null && error!=null){
                        callBack.onError(error.getMessage());
                    }
                });
        addToRequestQueue(stringRequest);

    }

    public void getSubCollForCollId(String id,final  ApiCallBack callBack){
        String url="http://159.65.94.189:800/home/subcollections/" + id;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    ArrayList<Subcollection> collection = (new Gson()).fromJson(response, new TypeToken<ArrayList<Subcollection>>() {}.getType());

                    if(callBack!=null){
                        callBack.didReceiveData(collection, didReceiveSubCollations);
                    }
                },
                error -> {
                    if(callBack!=null && error!=null){
                        callBack.onError(error.getMessage());
                    }
                });
        addToRequestQueue(stringRequest);
    }

    public void getAppsForSubCollId(String id,final ApiCallBack apiCallBack){

        String url="http://159.65.94.189:800/home/subcollection/" + id;




    }














}