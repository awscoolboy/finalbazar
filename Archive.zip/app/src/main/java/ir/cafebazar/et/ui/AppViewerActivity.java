package ir.cafebazar.et.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.transition.DrawableCrossFadeFactory;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.io.UnsupportedEncodingException;

import apps.cafebazaar.all.apps.R;
import ir.cafebazar.et.AndroidHelper;
import ir.cafebazar.et.ApplicationLoader;
import ir.cafebazar.et.SearchActivity;
import ir.cafebazar.et.model.CafeBazarApp;
import ir.cafebazar.et.model.Developer;
import ir.cafebazar.et.network.BaseApiController;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

public class AppViewerActivity extends AppCompatActivity{

    private ImageView app_icon;
    private TextView app_title;
    private TextView app_devloper;
    private TextView rating_amount;
    private TextView rating_count;
    private TextView app_size;
    private TextView downlod_count;
    private RecyclerView screenShotRv;
    private TextView app_desc;
    private TextView readMore;
    private Button install_button;

    private CafeBazarApp cafeBazarApp;
    private ImageAdapter imageAdapter;

    private boolean fromHome;
    //private AdView mAdView;

    private InterstitialAd mInterstitialAd;


    public void showAdd(){
        if(mInterstitialAd == null || !mInterstitialAd.isLoaded()) {
            return;
        }
        mInterstitialAd.show();
    }

    public void loadAdd(Context context){
        mInterstitialAd = new InterstitialAd(context);
        mInterstitialAd.setAdUnitId(ApplicationLoader.INTERSTITIAL_ID);
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener(){
                                          @Override
                                          public void onAdClosed() {
                                              mInterstitialAd.loadAd(new AdRequest.Builder().build());
                                          }

                                          @Override
                                          public void onAdFailedToLoad(int i) {
                                              super.onAdFailedToLoad(i);
                                              mInterstitialAd.loadAd(new AdRequest.Builder().build());

                                          }
                                      }

        );
    }



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.app_viewer_layout);
        loadAdd(this);
        cafeBazarApp=(CafeBazarApp)getIntent().getSerializableExtra("cafe_app");
        fromHome=getIntent().getBooleanExtra("from_home",false);
        if(cafeBazarApp==null || cafeBazarApp.getName()==null){
            finish();
            return;
        }
        if(getSupportActionBar()!=null){
            getSupportActionBar().setTitle(foramtString(cafeBazarApp.getName()));
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        app_icon=findViewById(R.id.app_logo);
        app_title =findViewById(R.id.app_titile);
        app_devloper=findViewById(R.id.app_devloper);
        rating_amount=findViewById(R.id.rating_tex_view);
        rating_count=findViewById(R.id.app_review_count);
        app_size=findViewById(R.id.app_size_text);
        downlod_count=findViewById(R.id.app_downloads);
        screenShotRv=findViewById(R.id.app_screen_shot);
        app_desc=findViewById(R.id.app_desc);
        install_button=findViewById(R.id.install_button);
        readMore=findViewById(R.id.read_more);
        readMore.setOnClickListener(view -> {

            ++ApplicationLoader.counter;
            if(ApplicationLoader.counter%2==0){
                showAdd();
                return;
            }
            if(cafeBazarApp.getDescription()==null){
                return;
            }

            AlertDialog.Builder builder=new AlertDialog.Builder(this);
            builder.setTitle(foramtString(cafeBazarApp.getName()));
            builder.setMessage(foramtString(cafeBazarApp.getDescription()));
            builder.create().show();

        });
        setAppData();
        if(fromHome){
            BaseApiController.getInstance(this).getAppbyPackageName(cafeBazarApp.getPackage_name(), new BaseApiController.ApiCallBack() {
                @Override
                public void didReceiveData(Object object, int type) {
                    if(object==null){
                        return;
                    }
                    if(type== BaseApiController.didReceiveAppByPackageName){
                         cafeBazarApp=(CafeBazarApp)object;
                         getDevloper();
                         updateView();
                    }
                }

                @Override
                public void onError(String error_message) {

                }
            });
        }

//        mAdView = findViewById(R.id.adView);
//        AdRequest adRequest = new AdRequest.Builder().build();
//        mAdView.loadAd(adRequest);

    }

    private void updateView(){
        app_size.setText(foramtString(cafeBazarApp.getSize()));
        downlod_count.setText(foramtString(cafeBazarApp.getInstalls()));
        if(cafeBazarApp.getDescription()==null || cafeBazarApp.getDescription().isEmpty()){
            readMore.setVisibility(View.GONE);
            app_desc.setText(foramtString(cafeBazarApp.getDescription()));
        }else {
            readMore.setVisibility(View.VISIBLE);
            app_desc.setText(foramtString(cafeBazarApp.getDescription()));

        }
        if(cafeBazarApp.getScreenshots()==null || cafeBazarApp.getScreenshots().isEmpty()){
            screenShotRv.setVisibility(View.GONE);

        }else{
            screenShotRv.setVisibility(View.VISIBLE);
            imageAdapter=new ImageAdapter(this);
            screenShotRv.setHasFixedSize(true);
            screenShotRv.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
            screenShotRv.setAdapter(imageAdapter);
        }

    }


    private void getDevloper(){
        if(cafeBazarApp.getDeveloper()!=null){
            BaseApiController.getInstance(this).getDevloperById(cafeBazarApp.getDeveloper(), new BaseApiController.ApiCallBack() {
                @Override
                public void didReceiveData(Object object, int type) {
                    if(object==null){
                        return;
                    }
                    Developer developer=(Developer)object;
                    app_devloper.setVisibility(View.VISIBLE);
                    app_devloper.setText(AndroidHelper.foramtString(developer.getName()));
                    app_devloper.setOnClickListener(view -> {

                        Intent intent=new Intent(AppViewerActivity.this,DeveloperAppsActivity.class);
                        intent.putExtra("developer",developer);
                        startActivity(intent);
                    });
                }
                @Override
                public void onError(String error_message) {

                }
            });

        }
    }


    private void setAppData(){
        app_title.setText(foramtString(cafeBazarApp.getName()));
        app_devloper.setText(foramtString(cafeBazarApp.getDeveloper()));
        rating_amount.setText(foramtString(cafeBazarApp.getRating_total()));
        rating_count.setText(foramtString(cafeBazarApp.getRating_total_count()));
        app_size.setText(foramtString(cafeBazarApp.getSize()));
        downlod_count.setText(foramtString(cafeBazarApp.getInstalls()));


        if(cafeBazarApp.getDescription()==null || cafeBazarApp.getDescription().isEmpty()){
            readMore.setVisibility(View.GONE);
            app_desc.setText(foramtString(cafeBazarApp.getDescription()));
        }else {
            app_desc.setText(foramtString(cafeBazarApp.getDescription()));

            ViewTreeObserver vto = app_desc.getViewTreeObserver();
            vto.addOnGlobalLayoutListener(() -> {
                Layout l = app_desc.getLayout();
                if ( l != null){
                    int lines = l.getLineCount();
                    if ( lines > 0)
                        if ( l.getEllipsisCount(lines-1) > 0){
                            readMore.setVisibility(View.VISIBLE);
                        }else{
                            readMore.setVisibility(View.GONE);
                        }
                }
            });

        }

        DrawableCrossFadeFactory factory =
                new DrawableCrossFadeFactory.Builder().setCrossFadeEnabled(true).build();


        Glide.with(this)
                .load("http://159.65.94.189:800/media/"+ cafeBazarApp.getIcon())
                .transition(withCrossFade(factory))
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(app_icon);


        if(cafeBazarApp.getScreenshots()==null || cafeBazarApp.getScreenshots().isEmpty()){
            screenShotRv.setVisibility(View.GONE);

        }else{
            screenShotRv.setVisibility(View.VISIBLE);
            imageAdapter=new ImageAdapter(this);
            screenShotRv.setHasFixedSize(true);
            screenShotRv.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
            screenShotRv.setAdapter(imageAdapter);
        }


        install_button.setOnClickListener(view -> {
            if(cafeBazarApp.getPackage_name()!=null){
                ++ApplicationLoader.counter;
                if(ApplicationLoader.counter%2==0){
                    showAdd();
                    return;
                }
                AndroidHelper.openAppRating(AppViewerActivity.this,cafeBazarApp.getPackage_name());
            }else{

            }
        });

        getDevloper();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.app_viewer_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_search) {
            Intent intent=new Intent(this, SearchActivity.class);
            startActivity(intent);

            return true;
        }else if(id==R.id.action_open_in_web){
            if(cafeBazarApp!=null){

                ++ApplicationLoader.counter;
                if(ApplicationLoader.counter%2==0){
                    showAdd();
                    return false;
                }
                String url="https://cafebazaar.ir/app/" + cafeBazarApp.getPackage_name()+ "/?l=fa";
                AndroidHelper.share(url,this);
//
//                CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
//                CustomTabsIntent customTabsIntent = builder.build();
//                builder.setToolbarColor(getColor(R.color.colorPrimary));
//                builder.setStartAnimations(this, R.anim.slide_in_right, R.anim.slide_out_left);
//                builder.setExitAnimations(this, R.anim.slide_in_left, R.anim.slide_out_right);
//                customTabsIntent.launchUrl(AppViewerActivity.this.getParent(), Uri.parse(url));

            }

        }else if(id==R.id.share_app){
            ++ApplicationLoader.counter;
            if(ApplicationLoader.counter%2==0){
                showAdd();
                return false;
            }
            AndroidHelper.share("https://play.google.com/store/apps/details?id=" +cafeBazarApp.getPackage_name(),this);

        }else if(id==android.R.id.home){
            finish();
        }

        return true;
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }




    private String foramtString(String data){
        if(data==null){
            return "";
        }
        String str = "";
        try {
            str = new String(data.getBytes("ISO-8859-1"), "UTF-8");
        } catch (UnsupportedEncodingException e) {

            e.printStackTrace();
        }
        String decodedStr = Html.fromHtml(str).toString();
        return decodedStr;
    }


    private class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.ImageViewHOlder>{


        private Context con;
        DrawableCrossFadeFactory factory;
        private ImageAdapter(Context context){
            this.con=context;
            factory=new DrawableCrossFadeFactory.Builder().setCrossFadeEnabled(true).build();
        }

        @NonNull
        @Override
        public ImageViewHOlder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

            View view= LayoutInflater.from(con).inflate(R.layout.screen_shot_item,viewGroup,false);
            return new ImageViewHOlder(view);
        }



        @Override
        public void onBindViewHolder(@NonNull ImageViewHOlder imageViewHOlder, int i) {

            Glide.with(con.getApplicationContext())
                    .load("http://159.65.94.189:800/media/" + cafeBazarApp.getScreenshots().get(i))
                    .transition(withCrossFade(factory))
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    //.placeholder(R.drawable.side_nav_bar)
                    .into(imageViewHOlder.imageView);

        }


        @Override
        public int getItemCount() {
            return cafeBazarApp.getScreenshots()!=null?cafeBazarApp.getScreenshots().size():0;
        }



        public class ImageViewHOlder extends RecyclerView.ViewHolder {
            private ImageView imageView;
            public ImageViewHOlder(@NonNull View itemView) {
                super(itemView);
                imageView=(ImageView)itemView;
            }
        }
    }



    private class ListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

        private final int profile=0;
        private final int install=1;
        private final int detials=2;
        private final int screenshot=3;
        private final int readMore=4;
        private final int desc=5;
        private final int devloper_apps=6;
        private final int cat_apps=7;


        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            return null;
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {

        }

        @Override
        public int getItemCount() {
            return 0;
        }
    }

}
