package ir.cafebazar.et.database;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Query;


@android.arch.persistence.room.Dao
public class AppDao{


}

