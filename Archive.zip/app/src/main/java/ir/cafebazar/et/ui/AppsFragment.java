package ir.cafebazar.et.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;


import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import apps.cafebazaar.all.apps.R;
import ir.cafebazar.et.ApplicationLoader;
import ir.cafebazar.et.model.Categories;
import ir.cafebazar.et.network.BaseApiController;


public class AppsFragment extends Fragment{

    private RecyclerView listView;
    private ListAdapter listAdapter;
    private List<Categories.Category> categoryList=new ArrayList<>();
    private ProgressBar progressBar;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view=LayoutInflater.from(getContext()).inflate(R.layout.catagory_fragment,container,false);

        progressBar=view.findViewById(R.id.progressBar);
        listView=view.findViewById(R.id.listView);
        listAdapter=new ListAdapter();
        listView.setLayoutManager(new LinearLayoutManager(getContext()));
        listView.setAdapter(listAdapter);

        getData();

        return view;
    }

    private void getData(){
        BaseApiController.getInstance(getContext()).getAppCategory(new BaseApiController.ApiCallBack() {
            @Override
            public void didReceiveData(Object object, int type) {

                if(object==null) {
                    displayErroMessage();
                    return;
                }
                if(type== BaseApiController.didReceivedAppCategory && object instanceof ArrayList){
                    categoryList=(ArrayList<Categories.Category>)object;
                    if(listAdapter!=null) {
                        listAdapter.notifyDataSetChanged();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                hideProgress();
                            }
                        },300);
                    }

                }
            }

            @Override
            public void onError(String error_message) {

            }
        });
    }

    private void displayErroMessage(){
        //check also for network connectiviey

    }



    private class ListAdapter extends RecyclerView.Adapter<ListAdapter.TextViewHolder>{


        @NonNull
        @Override
        public TextViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view=LayoutInflater.from(getContext()).inflate(R.layout.cat_list_item,viewGroup,false);
            return new TextViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull TextViewHolder textViewHolder, final int i) {

            Categories.Category category=categoryList.get(i);

            String str = "";
            try {
                str = new String(category.getName().getBytes("ISO-8859-1"), "UTF-8");
            } catch (UnsupportedEncodingException e) {

                e.printStackTrace();
            }
            String decodedStr = Html.fromHtml(str).toString();
            textViewHolder.simpleTextView.setText(decodedStr);

            textViewHolder.simpleTextView.setOnClickListener(view -> {

                ++ApplicationLoader.counter;
                if(ApplicationLoader.counter%3==0){
                    if(getContext() instanceof MainActivity){
                        ((MainActivity) getContext()).showAdd();
                        return;
                    }

                }

                Categories.Category category1 =categoryList.get(i);
                Intent intent=new Intent(getContext(),CategoryActivity.class);
                intent.putExtra("cat", category1);
                getContext().startActivity(intent);
            });


        }

        @Override
        public int getItemCount() {
            return categoryList!=null?categoryList.size():0;
        }

        class TextViewHolder extends RecyclerView.ViewHolder{

            TextView simpleTextView;
            public TextViewHolder(@NonNull View itemView) {
                super(itemView);
                simpleTextView=itemView.findViewById(R.id.textView);
                simpleTextView.setTypeface(Typeface.createFromAsset(getContext().getAssets(),"DroidNaskh-Regular.ttf"));

            }
        }

    }

    private void hideProgress(){
        if(progressBar!=null && listView!=null){
            int mShortAnimationDuration=getResources().getInteger(
                    android.R.integer.config_shortAnimTime);
            listView.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.INVISIBLE);
            listView.setAlpha(0f);
            listView.setVisibility(View.VISIBLE);
            listView.animate()
                    .alpha(1f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(null);
            progressBar.animate()
                    .alpha(0f)
                    .setDuration(mShortAnimationDuration)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            progressBar.setVisibility(View.GONE);
                        }
                    });
        }
    }



}
