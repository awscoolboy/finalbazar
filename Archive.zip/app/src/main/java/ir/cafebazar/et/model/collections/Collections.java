package ir.cafebazar.et.model.collections;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;


public class Collections {


    @SerializedName("count")
    private String count;

    @SerializedName("next")
    private String next;

    @SerializedName("previous")
    private String previous;

    @SerializedName("results")
    private ArrayList<Collection> results;


    public static class Collection{

        @SerializedName("id")
        private String id;

        @SerializedName("name")
        private String name;


        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }


    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getNext() {
        return next;
    }

    public void setNext(String next) {
        this.next = next;
    }

    public String getPrevious() {
        return previous;
    }

    public void setPrevious(String previous) {
        this.previous = previous;
    }

    public ArrayList<Collection> getResults() {
        return results;
    }

    public void setResults(ArrayList<Collection> results) {
        this.results = results;
    }
}
