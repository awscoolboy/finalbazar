package ir.cafebazar.et.model;

import android.arch.persistence.room.Entity;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;


public class BazaarApps {

    public abstract class Bazar extends ArrayList{

    }

    @SerializedName("count")
    private int count;

    @SerializedName("next")
    private String next;

    @SerializedName("previous")
    private String previous;

    @SerializedName("results")
    private List<CafeBazarApp> cafeBazarAppList;


    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getNext() {
        return next;
    }

    public void setNext(String next) {
        this.next = next;
    }

    public String getPrevious() {
        return previous;
    }

    public void setPrevious(String previous) {
        this.previous = previous;
    }

    public List<CafeBazarApp> getCafeBazarAppList() {
        return cafeBazarAppList;
    }

    public void setCafeBazarAppList(List<CafeBazarApp> cafeBazarAppList) {
        this.cafeBazarAppList = cafeBazarAppList;
    }
}
