package ir.cafebazar.et.ui;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.fragment.NavHostFragment;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.quinny898.library.persistentsearch.SearchBox;


import apps.cafebazaar.all.apps.R;
import ir.cafebazar.et.AndroidHelper;
import ir.cafebazar.et.ApplicationLoader;
import ir.cafebazar.et.SearchActivity;


public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{


    private NavController navController;
    private AdView mAdView;
    private InterstitialAd mInterstitialAd;
    private SearchBox searchBox;


    public void showAdd(){
        if(mInterstitialAd == null || !mInterstitialAd.isLoaded()) {
            return;
        }
        mInterstitialAd.show();
    }


    public void loadAdd(Context context){
        mInterstitialAd = new InterstitialAd(context);
        mInterstitialAd.setAdUnitId(ApplicationLoader.INTERSTITIAL_ID);
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener(){
            @Override
            public void onAdClosed() {
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }
        }

        );
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        loadAdd(this);
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


//        Toolbar toolbar = findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
//        updateToolBarTitile(getString(R.string.menu_home));

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);


        searchBox=findViewById(R.id.searchbox);
        searchBox.setHint("Bazaar Apps");
        searchBox.setLogoText("Bazaar Apps");
        searchBox.setLogoTextColor(Color.parseColor("#000000"));
        searchBox.enableVoiceRecognition(this);

        searchBox.setMenuListener(() -> {
            if(drawer.isDrawerOpen(Gravity.START)){
                drawer.closeDrawer(Gravity.START);
            }else {
                drawer.openDrawer(Gravity.START);
            }
        });

//        toolbar.setOnMenuItemClickListener(menuItem -> {
//
//            if(menuItem.getItemId()==R.id.action_search){
//                startActivity(new Intent(MainActivity.this, SearchActivity.class));
//            }
//            return true;
//        });



        NavHostFragment host=(NavHostFragment)getSupportFragmentManager().findFragmentById(R.id.baseFragment);
        navController=host.getNavController();

        //set defual value
        navigationView.setCheckedItem(R.id.nav_home);

        // navigationView.setItemIconTintList(null);


//        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
//                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
//        drawer.addDrawerListener(toggle);
//        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        navController.addOnDestinationChangedListener((controller, destination, arguments) -> {
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
       return navController.navigateUp();

    }

    private void updateToolBarTitile(String title){
        //getSupportActionBar().setTitle(title);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_search) {

            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {


        // Handle navigation view item clicks here.
        int id = item.getItemId();
        switch (id){
            case R.id.nav_home:
                updateToolBarTitile(getString(R.string.menu_home));
                navController.navigate(R.id.homeFragment);
                break;
            case R.id.nav_apps:
                updateToolBarTitile(getString(R.string.menu_apps));
                navController.navigate(R.id.appsFragment);

                break;
            case R.id.nav_games:
                updateToolBarTitile(getString(R.string.menu_games));
                navController.navigate(R.id.gamesFragment);
                break;

            case R.id.nav_tele_apps:
                updateToolBarTitile(getString(R.string.menu_tele_apps));
                navController.navigate(R.id.telegramApps);
                break;
            case R.id.nav_share:
                AndroidHelper.share("https://play.google.com/store/apps/details?id=apps.cafebazaar.all.apps",this);
                break;
            case R.id.nav_settings:
                break;
            case R.id.nav_google_play_top:
                updateToolBarTitile(getString(R.string.menu_google_play_tops));
                navController.navigate(R.id.google_play_tops);
                break;
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);

        return true;
    }



}
